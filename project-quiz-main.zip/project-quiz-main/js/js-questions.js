const JSExam={
    'question1':{
        question:"Which type of JavaScript language is ___",
        a:"Object-Oriented",
        b:"Object-Based",
        c:"Assembly-language",
        d:"High-level",
        correct:'b'
    },
    'question2':{
        question:"Which one of the following also known as Conditional Expression:",
        a:"Alternative to if-else",
        b:"Switch statement",
        c:"If-then-else statement",
        d:"immediate if",
        correct:'d'
    },
    'question3':{
        question:" In JavaScript, what is a block of statement?",
        a:"Conditional block",
        b:"block that combines a number of statements into a single compound statement",
        c:"both conditional block and a single statement",
        d:"block that contains a single statement",
        correct:'b'
    },
    'question4':{
        question:"When interpreter encounters an empty statements, what it will do:",
        a:"Shows a warning",
        b:"Prompts to complete the statement",
        c:"Throws an error",
        d:"Ignores the statements",
        correct:'d'
    },
    'question5':{
        question:" The function and var are known as:",
        a:"Keywords",
        b:"Data types",
        c:"Declaration statements",
        d:"Prototypes",
        correct:'c'
    },
    'question6':{
        question:"Which of the following variables takes precedence over the others if the names are the same?",
        a:"Global variable",
        b:"The local element",
        c:"The two of the above",
        d:"None of the above",
        correct:'b'
    },
    'question7':{
        question:"Which one of the following is the correct way for calling the JavaScript code?",
        a:"Preprocessor",
        b:"Triggering Event",
        c:"RMI",
        d:"Function/Method",
        correct:'d'
    },
    'question8':{
        question:" Which of the following option is used as hexadecimal literal beginning?",
        a:"00",
        b:"0x",
        c:"0X",
        d:"Both 0x and 0X",
        correct:'d'
    },
    'question9':{
        question:"When there is an indefinite or an infinite value during an arithmetic computation in a program, then JavaScript prints______.",
        a:"Prints an exception error",
        b:"Prints an overflow error",
        c:"Displays Infinity",
        d:"Prints the value as such",
        correct:'c'
    },
    'question5':{
        question:"In the JavaScript, which one of the following is not considered as an error:",
        a:"Syntax error",
        b:"Missing of semicolons",
        c:"Division by zero",
        d:"Missing of Bracket",
        correct:'c'
    }
}