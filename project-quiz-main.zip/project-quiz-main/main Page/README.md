# Simple-Bank-webstie
a simple design of the first page of a bank website . This website uses DOM advanced DOM events using JS
